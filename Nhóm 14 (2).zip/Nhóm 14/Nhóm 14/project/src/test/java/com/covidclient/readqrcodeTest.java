package com.covidclient;

import org.junit.Test;

public class readqrcodeTest {
    @Test
    public void testMain() {

    }
}
